# 证据账本格式

`tmp-claims.json`：

```json
{
  "question": "10 月 28 日议息会加息吗？",
  "as_of": "2026-10-26T03:00:00Z",
  "claims": [
    {
      "id": "C1",
      "text": "Polymarket 给 10 月按兵不动 93.5%，一个月内上涨约 60 个百分点",
      "type": "price",
      "as_of": "2026-10-26T03:00:00Z",
      "sources": [
        {"url": "https://polymarket.com/event/fed-decision-in-october-20260617190323537", "publisher": "Polymarket", "tier": "T0", "published_at": "2026-10-26"}
      ]
    },
    {
      "id": "C2",
      "text": "9 月 CPI 同比 3.7%，高于预期",
      "type": "fact",
      "as_of": "2026-10-26T03:00:00Z",
      "sources": [
        {"url": "https://www.bls.gov/news.release/cpi.nr0.htm", "publisher": "BLS", "tier": "T0", "published_at": "2026-10-14"}
      ]
    },
    {
      "id": "C3",
      "text": "有交易者以“20 年未连续两次加息”质疑市场定价偏高",
      "type": "view",
      "as_of": "2026-10-26T03:00:00Z",
      "sources": [
        {"url": "https://x.com/fort1kkk/status/2104964583165231610", "publisher": "@fort1kkk", "tier": "T4", "published_at": "2026-09-29"}
      ]
    },
    {
      "id": "C4",
      "text": "10 月不动已基本被定价，真正的分歧在 12 月",
      "type": "inference",
      "as_of": "2026-10-26T03:00:00Z",
      "basis": ["C1", "C2"],
      "sources": []
    }
  ]
}
```

## 字段

| 字段 | 说明 |
|---|---|
| `type` | `fact` 事实、`price` 价格、`consensus` 共识、`view` 观点、`inference` 推断 |
| `tier` | `T0`–`T4`，定义见 sources.md |
| `publisher` | 发布方。用于判断“独立来源”：同一发布方算一个 |
| `published_at` | 原文发布时间。不知道写 `unknown`，不要猜 |
| `basis` | 仅推断需要：所依据的结论 id |

## `check_claims.py` 的校验规则

| 规则 | 要求 |
|---|---|
| R1 必填 | 每条有 `id`、`text`、`type`、`as_of`；非推断至少 1 个来源 |
| R2 事实 | `fact`：有 1 个 T0，或 ≥2 个不同发布方的 T0–T2 |
| R3 价格 | `price`：至少 1 个 T0 或 T1 来源 |
| R4 共识 | `consensus`：至少 1 个 T1，或 ≥2 个不同发布方的 T1–T2 |
| R5 社区 | 只有 T4 来源的结论，`type` 只能是 `view` |
| R6 泛化词 | 出现“普遍 / 常见 / 大家 / 共识 / 主流 / 多数 / widely / commonly / most” 等词时，需要 ≥3 个不同发布方 |
| R7 推断 | `inference` 必须有 `basis`，且引用的 id 都存在 |
| R8 时间 | 来源 `published_at` 不能晚于结论的 `as_of`（防穿越） |
