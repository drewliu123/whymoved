# 来源分层

| 层级 | 是什么 | 能支撑什么 |
|---|---|---|
| T0 | 一手官方与盘口：统计局、央行、交易所、公司公告、监管文件、Polymarket/Kalshi 盘口 | 事实、价格 |
| T1 | 共识与隐含定价：FactSet、路透调查、彭博调查、CME FedWatch、期权隐含 | 共识、价格 |
| T2 | 一线媒体首发：Reuters、Bloomberg、WSJ、FT、CNBC、财新、第一财经 | 事实（需两家对上）、市场反应 |
| T3 | 机构观点：投行、研究所、知名分析师研报 | 观点（存“怎么看 + 条件句”，不存事实数字） |
| T4 | 社区信号：Reddit、X、小红书、雪球、HN、YouTube、Telegram | 观点、叙事、情绪、异动线索；**不能支撑事实** |

不收：纯转述聚合站、无时间无出处的“据报道”。转述命中同一事实时合并，不重复计来源。

## 按类别的来源清单

### 宏观与央行（event_pricing / theme）

- T0：`bls.gov`（非农、CPI）、`bea.gov`（PCE、GDP）、`federalreserve.gov`（声明、纪要、日历、讲话）、`fred.stlouisfed.org`、Polymarket Gamma 盘口
- T1：CME FedWatch、Reuters / Bloomberg 经济学家调查、Kalshi 盘口
- T2：Reuters、Bloomberg、WSJ、FT、CNBC
- T3：Goldman、Morgan Stanley、JPMorgan 等研报观点
- T4 社区：r/economics、r/wallstreetbets、r/investing、r/Polymarket、r/Kalshi、r/PredictionMarkets；小红书“美联储 加息”“议息”

### 预测市场（event_pricing）

- T0：Polymarket Gamma API、Kalshi 市场页、各市场 `description` 里的结算规则
- T1：同一事件在其他平台的定价、民调聚合
- T4 社区：r/Polymarket（专属）、r/Kalshi、r/PredictionMarkets、r/PredictionsMarkets；X 上 @Polymarket、@Kalshi

### 美股个股（asset）

- T0：SEC EDGAR（10-K、10-Q、8-K、13F、Form 4）、公司 IR 页、财报电话会实录
- T1：一致预期、期权隐含波动
- T2：Reuters、Bloomberg、CNBC
- T4 社区：r/stocks、r/investing、r/wallstreetbets、r/SecurityAnalysis；该公司的专属版块

### 加密资产（asset）

- T0：链上浏览器、项目官方公告、交易所公告、DefiLlama
- T1：资金费率、期权隐含、预测市场价格
- T4 社区：r/CryptoCurrency、r/ethfinance、r/defi；X 上项目官方和创始人账号

### A 股 / 港股（asset / theme）

- T0：巨潮资讯、上交所、深交所、港交所披露易、国家统计局、人民银行
- T2：财新、第一财经、证券时报、路透中文
- T4 社区：雪球、小红书、东方财富股吧（只当情绪）

## 作者库规则（`data/authors.json`）

每个作者有 `status`：

| status | 含义 | 使用方式 |
|---|---|---|
| `core` | 复盘命中率高 | 每次同类研究都定向抓他的帖子 |
| `watch` | 新发现或样本不足 | 定向抓，但观点权重减半 |
| `demoted` | 复盘命中率低 | 不再定向抓；被搜到时照常参与排序 |

升降级由 `scripts/authors.py grade` 自动执行：
- 已复盘次数 ≥ 3 且命中率 ≥ 60% → `core`
- 已复盘次数 ≥ 3 且命中率 ≤ 30% → `demoted`
- 其他 → 保持 `watch`

新作者纳入条件（community-scout 判断）：本次检索里至少 2 条帖子命中主题，且他在本次结果中的帖子至少一半与主题相关。
