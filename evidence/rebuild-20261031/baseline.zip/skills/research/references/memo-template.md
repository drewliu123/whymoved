# 研究备忘录模板

```
投研助手 · {类型} · {ENTITY} · 截面 {AS_OF}

一句话：{用一句话说清楚定价、基准和分歧在哪里}

**定价与对标**
- 市场定价：{盘口概率 / 价格，及 1 天 / 1 周 / 1 月变化} [C1]
- 交叉定价：{FedWatch / 另一平台 / 期权 / 民调} [C?]
- 历史基准：{类似情形的历史频率} [C?]
- 共识：{调查中值或主流机构判断} [C?]

**发生了什么**（按时间线，只放 fact / price）
- {日期} {事件}，定价从 {a} 变到 {b} [C?]

**市场在想什么**（view，注明来自谁、多少互动）
- {观点}，per [@handle](url) [C?]

**分歧与推断**（inference，写明依据）
- {推断} [C?，依据 C1、C2]

**值得研究的假设**
| 编号 | 假设 | 验证时间点 | 证伪条件 |
|---|---|---|---|
| H1 | … | {日期} | 出现 {什么} 则不成立 |

**反方**
- {red-team 给出的最强反方论据}

**证据缺口**
- {没取到的层级 / 校验没过被删掉的结论 / 失败的来源}

本备忘录是研究材料，不构成投资建议。
```

规则：
- 每句结论后面都有账本编号。
- 正文用 `[名称](url)` 链接，不另附来源列表。
- 定价、日期、数字只抄账本，不在正文里改写数值。
- 没有可靠解释时直接写“无可靠解释”，不硬凑。

## `tmp-memo.json`（登记复盘用）

```json
{
  "question": "10 月 28 日议息会加息吗？",
  "type": "event_pricing",
  "entity": "Fed Decision in October",
  "as_of": "2026-10-26T03:00:00Z",
  "market_snapshot": [
    {"source": "polymarket", "slug": "fed-decision-in-october-20260617190323537", "outcome": "No change", "prob": 0.935}
  ],
  "hypotheses": [
    {
      "id": "H1",
      "text": "10 月 28 日维持 3.75–4.00% 不变",
      "verify_by": "2026-10-28",
      "falsify_if": "宣布加息或降息",
      "my_prob": 0.95,
      "market_prob": 0.935,
      "authors": [
        {"handle": "fort1kkk", "platform": "x", "stance": "oppose"}
      ]
    }
  ]
}
```

- `my_prob`：`forecast.py finalize` 算出的 `final_prob`，不能手写；`market_prob`：登记时的市场定价。复盘时两者都和结果比，看本助手有没有比市场更准。
- `authors`：对这个假设表过态的作者，`stance` 是 `support`（支持）或 `oppose`（反对）。复盘给假设打分时，脚本自动给这些作者记命中或未命中。

## `tmp-forecast.json`（概率判断用）

```json
{
  "as_of": "2026-10-26T03:00:00Z",
  "forecasts": [
    {
      "hypothesis_id": "H1",
      "mode": "market",
      "question": "10 月 28 日 FOMC 维持利率不变？",
      "yes_means": "声明公布的目标区间仍为 3.75–4.00%",
      "window_start": "2026-10-26",
      "window_end": "2026-10-28",
      "resolution_source": "federalreserve.gov 声明",
      "market_prob": 0.935,
      "market_source": "Polymarket fed-decision-in-october",
      "evidence_ids": ["C1", "C2"]
    },
    {
      "hypothesis_id": "H2",
      "mode": "independent",
      "question": "12 月 10 日 FOMC 声明出现至少 1 张反对票？",
      "yes_means": "声明投票记录中有至少一位委员投反对票",
      "window_start": "2026-12-09",
      "window_end": "2026-12-10",
      "resolution_source": "federalreserve.gov 声明",
      "evidence_ids": ["C3", "C5"],
      "trials": [0.41, 0.38, 0.44]
    }
  ]
}
```

- `mode`：有截面时点的可成交价格用 `market`（`final_prob` 就是 `market_prob`，不需要 `trials`）；否则用 `independent`，不填 `market_prob`，`trials` 是 3 个 forecaster 子 Agent 各自返回的 `p`，原样照抄。
- `finalize` 会写回 `final_prob`、`method_version`、`evidence_hash`；之后改动账本或手改概率，`check` 和 `journal.py add` 都会拒绝。
- 备忘录里在概率旁注明来源：`market` 写“市场价”，`independent` 写“无市场参照，可信度较低”。
- 复盘统计里，market 模式的概率与市场相同；能检验本助手判断力的是 independent 模式那部分。
