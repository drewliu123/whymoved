# 投研助手

一个 Claude Code 插件：把一个投研问题变成**有证据约束、可复盘**的研究备忘录。覆盖预测市场、宏观事件、单一资产、行业主题、人物机构。

输出的是研究建议（定价与基准的差异、分歧点、值得研究的假设、证伪条件），**不是买卖建议**。

## 用法

```
/touyan:research Polymarket 上 10 月议息定价合理吗
/touyan:research 英伟达财报前市场在想什么
/touyan:research review          # 复盘到期的假设
```

## 工作流

```
问题
 │
 ├─ 1 路由：判断类型（事件定价 / 资产 / 主题 / 人物）
 ├─ 2 拆解：按类型的固定角度拆成检索计划（模型只填词）
 ├─ 3 来源：按类型取 T0–T4 来源 + 作者库里的 core / watch 作者
 ├─ 4 取证（并行）
 │    ├─ fact-collector   T0–T2 官方 / 共识 / 媒体，带原句和发布时间
 │    ├─ polymarket.py    盘口概率与变化
 │    └─ community-scout  T4 社区（优先用 last30days），并发现新作者
 ├─ 5 证据账本 → check_claims.py 校验（R1–R8），不过的结论补证据或删掉
 ├─ 6 red-team 反方审查：最强反方、过度推断、证伪条件
 ├─ 6.5 概率判断：问题契约 → 有市场价直接用市场价；没有则 3 个 forecaster 只读冻结证据规则优先判断 → forecast.py 计算
 ├─ 7 输出备忘录，登记假设进复盘账本，新作者进作者库
 └─ 8 复盘：到期打分 → 作者自动升降级 → 本助手 vs 市场的 Brier 分数
```

## 目录

| 路径 | 内容 |
|---|---|
| `skills/research/SKILL.md` | 主流程 |
| `skills/research/references/templates.md` | 四类问题的固定拆解角度 |
| `skills/research/references/sources.md` | T0–T4 来源分层、各类别来源清单、作者升降级规则 |
| `skills/research/references/evidence.md` | 证据账本格式与校验规则 |
| `skills/research/references/memo-template.md` | 备忘录模板与复盘登记格式 |
| `agents/` | 四个子 Agent：fact-collector、community-scout、red-team、forecaster（只读冻结证据给出概率） |
| `scripts/forecast.py` | 概率判断：校验问题契约；有市场价时概率取市场价，没有时取 3 个规则优先判断的均值；写回可复核的 `final_prob` |
| `research/prob-eval/` | 概率方法评测：协议、题集、证据包、各轮结果（RESULTS.md）与脚本 |
| `scripts/polymarket.py` | Polymarket 只读查询（搜索市场、取概率和变化、结算规则） |
| `scripts/check_claims.py` | 证据账本校验 |
| `scripts/journal.py` | 复盘账本：登记、到期、打分（只追加）、Brier 对比 |
| `scripts/authors.py` | 作者库：记录、打分、按命中率升降级 |
| `data/authors.json` | 作者库（种子名单都是 watch，未经复盘） |
| `journal/` | 复盘账本 `memos.jsonl`；每份研究的永久归档 `<memo_id>/`（memo.json、claims.json、memo.md、plan.json）；`tmp-*` 是每次覆盖的临时文件 |
| `tests/` | 脚本单元测试 |

数据目录默认就是本文件夹，可以用环境变量 `TOUYAN_HOME` 改到别处。插件更新不会覆盖账本和作者库。

## 安装

```bash
claude plugin marketplace add ~/Desktop/投研助手
claude plugin install touyan@touyan-local
```

改了本文件夹里的技能或子 Agent 之后，更新安装副本：

```bash
claude plugin marketplace update touyan-local && claude plugin update touyan@touyan-local
```

## 依赖

- Python 3.9+，只用标准库
- 可选：[last30days](https://github.com/mvanhorn/last30days-skill) 插件。装了社区取证会更全（Reddit、X、HN、Polymarket、小红书）；没装就退回限定域名的网页搜索

## 测试

```bash
cd ~/Desktop/投研助手 && python3 -m unittest discover -s tests
```

## 已知限制

- 拆解和综合仍由大模型完成，同一问题两次运行的检索词可能不同；固定的是角度和证据规则。
- 社区来源受本机网络影响：当前 YouTube 被拦，小红书依赖本地 xiaohongshu-mcp 服务。
- 复盘样本少于 30 条时，“比市场更准 / 不如市场”只是记录，不能当结论。
