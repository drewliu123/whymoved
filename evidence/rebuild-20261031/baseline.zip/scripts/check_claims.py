#!/usr/bin/env python3
"""Validate an evidence ledger against rules R1-R8 (see references/evidence.md).

Exit 0 when every claim passes, 1 when any claim fails, 2 on unreadable input.
"""

import argparse
import json
import re
import sys
from pathlib import Path

from common import parse_date

TYPES = {"fact", "price", "consensus", "view", "inference"}
TIERS = {"T0", "T1", "T2", "T3", "T4"}
GENERALIZERS = re.compile(
    r"普遍|常见|大家|共识|主流|多数|大多|广泛|一致认为|普遍认为|"
    r"\bwidely\b|\bcommonly\b|\bmost\b|\bconsensus\b|\beveryone\b",
    re.IGNORECASE,
)


def publishers(sources, tiers) -> set:
    return {
        (s.get("publisher") or "").strip().lower()
        for s in sources
        if s.get("tier") in tiers and (s.get("publisher") or "").strip()
    }


def check_claim(claim: dict, ids: set) -> list:
    errs = []
    cid = claim.get("id", "?")
    ctype = claim.get("type")
    text = claim.get("text") or ""
    sources = claim.get("sources") or []

    # R1 required fields
    for field in ("id", "text", "type", "as_of"):
        if not claim.get(field):
            errs.append(f"R1 缺少字段 {field}")
    if ctype and ctype not in TYPES:
        errs.append(f"R1 type 必须是 {sorted(TYPES)} 之一，现在是 {ctype!r}")
    if ctype != "inference" and not sources:
        errs.append("R1 非推断结论至少要有 1 个来源")
    for s in sources:
        if s.get("tier") not in TIERS:
            errs.append(f"R1 来源 {s.get('url', '?')} 的 tier 无效：{s.get('tier')!r}")
        if not s.get("url"):
            errs.append("R1 来源缺少 url")

    tiers = {s.get("tier") for s in sources}

    # R2 facts
    if ctype == "fact" and "T0" not in tiers and len(publishers(sources, {"T0", "T1", "T2"})) < 2:
        errs.append("R2 事实需要 1 个 T0，或 ≥2 个不同发布方的 T0–T2")
    # R3 prices
    if ctype == "price" and not tiers & {"T0", "T1"}:
        errs.append("R3 价格只能来自盘口或隐含定价（T0/T1）")
    # R4 consensus
    if ctype == "consensus" and "T1" not in tiers and len(publishers(sources, {"T1", "T2"})) < 2:
        errs.append("R4 共识需要 1 个 T1，或 ≥2 个不同发布方的 T1–T2")
    # R5 community-only claims stay opinions
    if sources and tiers == {"T4"} and ctype != "view":
        errs.append("R5 只有社区来源（T4）的结论，type 只能是 view")
    # R6 generalizing words need breadth
    match = GENERALIZERS.search(text)
    if match and len(publishers(sources, TIERS)) < 3:
        errs.append(f"R6 用了泛化词“{match.group(0)}”，但不同发布方不足 3 个；改写措辞或补来源")
    # R7 inferences cite their basis
    if ctype == "inference":
        basis = claim.get("basis") or []
        if not basis:
            errs.append("R7 推断必须写 basis（依据的结论 id）")
        missing = [b for b in basis if b not in ids]
        if missing:
            errs.append(f"R7 basis 引用了不存在的 id：{missing}")
        if cid in basis:
            errs.append("R7 推断不能引用自己")
    # R8 no look-ahead
    as_of = parse_date(claim.get("as_of", ""))
    for s in sources:
        published = parse_date(s.get("published_at", ""))
        if as_of and published and published > as_of:
            errs.append(f"R8 来源发布时间 {s.get('published_at')} 晚于截面 {claim.get('as_of')}（穿越）")
    return errs


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("ledger", type=Path)
    p.add_argument("--json", action="store_true", help="机器可读输出")
    args = p.parse_args()
    try:
        ledger = json.loads(args.ledger.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"读不了账本：{exc}", file=sys.stderr)
        return 2

    claims = ledger.get("claims") or []
    ids = {c.get("id") for c in claims}
    dupes = sorted({i for i in ids if [c.get("id") for c in claims].count(i) > 1})
    results = {c.get("id", f"#{n}"): check_claim(c, ids) for n, c in enumerate(claims)}
    if dupes:
        results.setdefault("_ledger", []).append(f"R1 id 重复：{dupes}")

    failed = {k: v for k, v in results.items() if v}
    if args.json:
        print(json.dumps({"passed": not failed, "total": len(claims), "failures": failed}, ensure_ascii=False, indent=2))
    else:
        for cid, errs in results.items():
            print(f"{'✗' if errs else '✓'} {cid}")
            for e in errs:
                print(f"    {e}")
        print(f"\n{len(claims) - len(failed)}/{len(claims)} 条通过")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
